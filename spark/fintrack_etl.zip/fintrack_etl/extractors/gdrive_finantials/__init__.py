# Deixa o diretório 'ingestion_sap' como um pacote Python

